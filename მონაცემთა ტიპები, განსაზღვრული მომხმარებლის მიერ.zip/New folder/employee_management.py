# თანამშრომლების მართვის სისტემა

class Employee:
    """მთავარი Employee კლასი"""
    
    def __init__(self, name, salary):
        """Employee-ს ინიციალიზაცია"""
        if salary < 0:
            raise ValueError("ხელფასი არ უნდა იყოს უარყოფითი!")
        self.name = name
        self.salary = salary
    
    def show_info(self):
        """თანამშრომლის ინფორმაციის ჩვენება"""
        print(f"სახელი: {self.name}, ხელფასი: {self.salary}")
    
    def work(self):
        """მუშაობის სიმულაცია"""
        print("Employee is working")
    
    def raise_salary(self, amount):
        """ხელფასის გაზრდა"""
        if amount < 0:
            raise ValueError("ხელფასის გაზრდა არ უნდა იყოს უარყოფითი!")
        self.salary += amount
        print(f"ხელფასი გაზრდილია {amount}-ით. ახალი ხელფასი: {self.salary}")


class Developer(Employee):
    """Developer კლასი - Employee-ს შვილობილი კლასი"""
    
    def __init__(self, name, salary, programming_language):
        """Developer-ის ინიციალიზაცია"""
        super().__init__(name, salary)
        self.programming_language = programming_language
    
    def code(self):
        """კოდის დაწერის სიმულაცია"""
        print("Writing code...")
    
    def work(self):
        """მუშაობის გადაფარვა - Developer ის კონტექსტში"""
        print("Developer is coding")


class Designer(Employee):
    """Designer კლასი - Employee-ს შვილობილი კლასი"""
    
    def __init__(self, name, salary, design_tool):
        """Designer-ის ინიციალიზაცია"""
        super().__init__(name, salary)
        self.design_tool = design_tool
    
    def create_design(self):
        """დიზაინის შექმნის სიმულაცია"""
        print("Creating design...")
    
    def work(self):
        """მუშაობის გადაფარვა - Designer-ის კონტექსტში"""
        print("Designer is designing")


# მთავარი პროგრამა
if __name__ == "__main__":
    print("=" * 50)
    print("თანამშრომლების მართვის სისტემა")
    print("=" * 50)
    
    # Developer ობიექტის შექმნა
    print("\n Developer:")
    print("-" * 50)
    developer = Developer("გიორგი", 5000, "Python")
    developer.show_info()
    developer.work()
    developer.code()
    developer.raise_salary(500)
    
    # Designer ობიექტის შექმნა
    print("\n Designer:")
    print("-" * 50)
    designer = Designer("ნინო", 4500, "Figma")
    designer.show_info()
    designer.work()
    designer.create_design()
    designer.raise_salary(300)
    
    # დამატებითი მაგალითი
    print("\n მეორე Developer:")
    print("-" * 50)
    developer2 = Developer("დავით", 5500, "JavaScript")
    developer2.show_info()
    developer2.work()
    developer2.code()
    
    print("\n" + "=" * 50)
    print("სისტემა დასრულდა")
    print("=" * 50)
